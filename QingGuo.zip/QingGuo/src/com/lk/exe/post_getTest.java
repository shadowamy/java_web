package com.lk.exe;

import com.lk.util.Http_messageRequest;

public class post_getTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "ƻ��";
		//System.out.println(name);
        String s=Http_messageRequest.sendPost("http://localhost:8080/QingGuo/Qbject_nameRequest", "key="+name);
        System.out.println(s);
		
	}

}
